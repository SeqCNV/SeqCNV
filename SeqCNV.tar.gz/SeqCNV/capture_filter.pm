#!/usr/bin/perl
#
#   capture_filter.pm
#
#
#

package capture_filter;
use strict;
use warnings;
use Carp;
use FileHandle;
use POSIX;
use constant DEBUG => 0;

#use constant ABNORMAL_RATE = 0.3;

our @ISA    = qw/Exporter/;
our @EXPORT =
  qw(exclude_targets remove_abnormal filter load_targets convet_to_log_ratio);

my %CHR_BIN = ();

sub filter {
	my $WIN_SIZE = shift;

	#	my $ABNORMAL_RATE = 0.3;
	my $LOG = shift || *STDOUT;

	# input sam file must be sorted by POSition
	my $IN = shift || *STDIN;

	#	my $file_start = $IN->getpos();
	my $WIN_INFO = shift || *STDOUT;

	#	my $REMOVED = shift || *STDOUT;
	#	my $NORMAL  = shift;

	my $STEP_SIZE = $WIN_SIZE / 2;

	my $CHR     = "";
	my $CUR_CHR = "";
	my $POS     = 0;

	my @BIN_READS = ();

	#	remind_time("Start to count reads for each bin\n");

	while (<$IN>) {

		chomp;
		( my $QNAME, my $FLAG, $CHR, $POS, my $REST ) = split /\t/, $_, 5;

		#only process the first 2 chr in debug mode
		if ( DEBUG && $CHR eq "chr3" ) {
			last;
		}

		#link each chromosome to a reads_per_bin array
		if ( $CUR_CHR ne $CHR ) {
			if ( $CUR_CHR ne "" ) {
				$CHR_BIN{$CUR_CHR} = [@BIN_READS];
			}
			@BIN_READS = ();
			$CUR_CHR   = $CHR;
		}
		my $bin_index = int( $POS / $STEP_SIZE );

		#increase count for 2 adjacent bins
		$BIN_READS[$bin_index] += 1;
		if ( $bin_index > 0 ) {
			$BIN_READS[ $bin_index - 1 ] += 1;
		}
	}

	#do not forget the last one
	$CHR_BIN{$CUR_CHR} = [@BIN_READS];

	#to save memory
	@BIN_READS = ();

	#output the sliding window info
	for my $key ( keys %CHR_BIN ) {
		my @value = @{ $CHR_BIN{$key} };
		for ( my $i = 0 ; $i < $#value ; $i++ ) {
			if ( not defined( $value[$i] ) ) {
				$_ = 0;
			}
			else {
				$_ = $value[$i];
			}
			print $WIN_INFO "$key\t$i\t$_\n";
		}
	}

	my @READS_FREQ = ();
	my $READS_NO   = 0;

	for my $key ( keys %CHR_BIN ) {
		my @value = @{ $CHR_BIN{$key} };
		for ( my $i = 0 ; $i < $#value ; $i++ ) {
			if ( not defined( $value[$i] ) ) {
				$CHR_BIN{$key}->[$i] = 0;
				$_ = 0;
			}
			else {
				$_ = $value[$i];
			}
			$READS_FREQ[$_] += 1;
			$READS_NO       += 1;
		}
	}

	#output the frequency info to visualize later
	for my $i ( 0 .. $#READS_FREQ ) {
		my $freq = defined( $READS_FREQ[$i] ) ? $READS_FREQ[$i] : 0;
		print $LOG "$i\t$freq\n";
	}

#	my $bound     = $READS_NO * $ABNORMAL_RATE;
#	my $min_count = 0;
#	my $low_bound = 0;
#	for my $i ( 0 .. $#READS_FREQ ) {
#		$low_bound += $READS_FREQ[$i];
#		if ( $low_bound > $bound ) {
#			$min_count = $i;
#			last;
#		}
#	}
#	print
#	  "all reads falling in a bin with count < $min_count will be discarded\n";

#	my $max_count = 0;
#	my $up_bound  = 0;
#	for ( my $i = $#READS_FREQ ; $i > 0 ; $i-- ) {
#		$up_bound += $READS_FREQ[$i];
#		if ( $up_bound > $bound ) {
#			$max_count = $i;
#			last;
#		}
#	}
#	print
#	  "all reads falling in a bin with count > $max_count will be discarded\n";
   #
   #	#to re-locate file handle to the beginning
   #	$IN->setpos($file_start);
   #
   #	remind_time("Start to split reads according to the counts\n");
   #
   #	while (<$IN>) {
   #		chomp;
   #		( my $QNAME, my $FLAG, $CHR, $POS, my $REST ) = split /\t/, $_, 5;
   #
   #		#only process the first 2 chr in debug mode
   #		if ( DEBUG && $CHR eq "3" ) {
   #			last;
   #		}
   #
   #		my $bin_index        = int( $POS / $STEP_SIZE );
   #		my $reads_count      = $CHR_BIN{$CHR}->[$bin_index];
   #		my $next_reads_count =
   #		  $CHR_BIN{$CHR}[ $bin_index == 0 ? $bin_index : $bin_index - 1 ];
   #		if (   $reads_count < $min_count
   #			|| $reads_count > $max_count
   #			|| $next_reads_count < $min_count
   #			|| $next_reads_count > $max_count )
   #		{
   #			print $REMOVED "$_\n";
   #		}
   #		else {
   #			print $NORMAL "$_\n";
   #		}
   #	}
}

my %CHR_TARGET = ();

sub load_targets {
	my $TARGET      = shift || croak "No target file specified";
	my $Pre_EXPAND  = shift || 0;
	my $Post_EXPAND = shift || 0;

	my $CHR           = "";
	my $POS           = 0;
	my $FIRST         = 0;
	my $LAST          = 0;
	my $TARGET_POS    = 0;
	my $TARGET_LENGTH = 0;

	#	remind_time("Start to load targets\n");

	while (<$TARGET>) {
		chomp;
		( $CHR, $FIRST, $LAST, my $rest ) = split /\t/;
		# if ( not( $CHR =~ m/^chr/ ) ) {
		# 	next;
		# }

		# else {
		# 	$CHR =~ s/chr//;
		# }

        if ( $CHR =~ m/^chr/ ) {
          $CHR =~ s/chr//;
        }

		$FIRST -= $Pre_EXPAND;
		$LAST += $Post_EXPAND;

		$TARGET_POS    = ( $FIRST + $LAST ) / 2;
		$TARGET_LENGTH = abs( $LAST - $FIRST );

		if ( not defined( $CHR_TARGET{$CHR} ) ) {
			my $target_info =
			  [ [ $FIRST, $LAST, $TARGET_POS, $TARGET_LENGTH ] ];
			$CHR_TARGET{$CHR} = $target_info;
		}
		else {
			push(
				@{ $CHR_TARGET{$CHR} },
				[ $FIRST, $LAST, $TARGET_POS, $TARGET_LENGTH ]
			);
		}
	}

	#sort target arrays for each chr
	foreach my $key ( keys %CHR_TARGET ) {
		my @value = @{ $CHR_TARGET{$key} };

		#sort by the start position
		@value = sort { $a->[0] <=> $b->[0] } @value;
		$CHR_TARGET{$key} = \@value;
	}
}

sub merge_targets {

	#re-sort keys
	my @old_keys    = keys %CHR_TARGET;
	my @sorted_keys = sort_hash_keys( \@old_keys );
	foreach my $key (@sorted_keys) {
		my @value = @{ $CHR_TARGET{$key} };
		my @updated_value = ();

		my $FIRST = $value[0]->[0];
		my $LAST = $value[0]->[1];
		my $TARGET_POS = ( $FIRST + $LAST ) / 2;
		my $TARGET_LENGTH = abs( $LAST - $FIRST );

		my $l = scalar(@value) - 1;
		for my $index (1 .. $l) {
			my $cur_start = $value[$index]->[0];
			my $cur_end = $value[$index]->[1];
			my $distance = $cur_start - $LAST;
			if ($distance > 0) {
				push(@updated_value, [$FIRST, $LAST, $TARGET_POS, $TARGET_LENGTH]);
				$FIRST = $cur_start;
				$LAST = $cur_end;
			} else {
				$LAST = $cur_end if ($cur_end > $LAST);
				$TARGET_POS = ( $FIRST + $LAST ) / 2;
				$TARGET_LENGTH = abs( $LAST - $FIRST );
			}
		}
		push(@updated_value, [$FIRST, $LAST, $TARGET_POS, $TARGET_LENGTH]);

#		foreach my $t (@updated_value) {
#			print STDOUT "$key\t$t->[0]\t$t->[1]\n";
#		}

		$CHR_TARGET{$key} = \@updated_value;
	}
}

sub get_target_sizes {
	my $size_file = shift || *STDIN;
	print $size_file "Chromosomal\t\n";
	for my $key ( keys %CHR_TARGET ) {
		my @value = @{ $CHR_TARGET{$key} };
	}
}

sub total_target_coverage {

	#get the total target size
	my $target_size = 0;
	for my $key ( keys %CHR_TARGET ) {
		my @value     = @{ $CHR_TARGET{$key} };
		my $cur_first = 0;
		my $cur_last  = 0;
		my $target_no = @value;

		for ( my $i = 0 ; $i < $target_no ; $i++ ) {
			if ( $value[$i][0] > $cur_last ) {
				$target_size += $cur_last - $cur_first;
				$cur_first = $value[$i][0];
			}
			if ( $value[$i][1] > $cur_last ) {
				$cur_last = $value[$i][1];
			}
		}
		$target_size += $cur_last - $cur_first;
	}
	print "the total target size is: $target_size\n";
	my $percent = $target_size / 30000000;
	print "with a whole genome percent of: $percent\%\n";
}

my %CHR_COUNT = ();

sub get_on_target_count {
	my $IN = shift || croak "No input capture file specified $!";

	my $CHR   = "";
	my $POS   = 0;
	my $FIRST = 0;
	my $LAST  = 0;

	my $CUR_TARGET = 0;
	my $CUR_CHR    = "";

	my %CHR_COUNT = ();

	#initialize CHR_COUNT hash table to zero
	foreach my $key ( keys %CHR_TARGET ) {
		my @value = @{ $CHR_TARGET{$key} };
		foreach my $i ( 0 .. $#value ) {
			$CHR_COUNT{$key}->[$i] = 0;
		}
	}

	#to save de-reference time
	my $target_info = ();
	while (<$IN>) {
		chomp;
		( my $QNAME, my $FLAG, $CHR, $POS, my $MAPQ, my $CIGAR, my $REST ) =
		  split /\t/, $_, 7;

		if ( not( $CHR =~ m/^chr/ ) ) {
			next;
		}

		else {
			$CHR =~ s/chr//;
		}

		#we don't want duplicated, unmapped and Mitochodia reads
		next if ( $CIGAR eq "*" );    #|| ( $FLAG > 1024 );
		next if $CHR =~ /^M/;

		if ( $CUR_CHR ne $CHR ) {
			$CUR_TARGET  = 0;
			$CUR_CHR     = $CHR;
			$target_info = $CHR_TARGET{$CHR};
		}

		#croak "chr name does not match $!" unless defined($target_info);
		#the chr name may not in the target file
		next unless defined($target_info);
		while ( defined( $target_info->[ $CUR_TARGET + 1 ] )
			&& $POS > $target_info->[$CUR_TARGET]->[1] )
		{
			$CUR_TARGET += 1;
		}
		$FIRST = $target_info->[$CUR_TARGET]->[0];
		$LAST  = $target_info->[$CUR_TARGET]->[1];
		if ( $POS < $FIRST || $POS > $LAST ) {
			next;
		}
		else {
			$CHR_COUNT{$CUR_CHR}->[$CUR_TARGET] += 1;

			#make sure overlapped targets get counted
			my $NEXT_TARGET = $CUR_TARGET + 1;
			while ( defined( $target_info->[$NEXT_TARGET] )
				&& $POS > $target_info->[$NEXT_TARGET]->[0] )
			{
				if ( $POS < $target_info->[$NEXT_TARGET]->[1] ) {
					$CHR_COUNT{$CUR_CHR}->[$NEXT_TARGET] += 1;
				}
				$NEXT_TARGET += 1;
			}
		}
	}
	return %CHR_COUNT;
}

sub poisson_on_target_count {
	my $IN = shift || croak "No input capture file specified $!";

	my $CHR   = "";
	my $POS   = 0;
	my $FIRST = 0;
	my $LAST  = 0;

	my $CUR_TARGET = 0;
	my $CUR_CHR    = "";

	#do not rely on global variable
	my %CHR_COUNT      = ();
	my %CHR_COUNT_POIS = ();

	#for each target, we maintain a hash table
	my @TARGET_BASE = ();

	#initialize CHR_COUNT hash table to zero
	foreach my $key ( keys %CHR_TARGET ) {
		my @value = @{ $CHR_TARGET{$key} };
		foreach my $i ( 0 .. $#value ) {
			$CHR_COUNT{$key}->[$i]      = 0;
			$CHR_COUNT_POIS{$key}->[$i] = 0;
		}
	}

	#to save de-reference time
	my @target_info = ();
	while (<$IN>) {
		chomp;
		( my $QNAME, my $FLAG, $CHR, $POS, my $MAPQ, my $CIGAR, my $REST ) =
		  split /\t/, $_, 7;

		if ( not( $CHR =~ m/^chr/ ) ) {
			next;
		}

		else {
			$CHR =~ s/chr//;
		}

		#we don't want unmapped and Mitochodia reads, how about duplicated ones?
		next if ( $CIGAR eq "*" );    #|| ( $FLAG > 1024 );
		next if $CHR =~ /^M/;

		if ( $CUR_CHR ne $CHR ) {
			#update reads count when changing chromosome
			if ( @TARGET_BASE > 0 ) {
				update_count_pois(\@TARGET_BASE, $CHR_COUNT{$CUR_CHR}, $CHR_COUNT_POIS{$CUR_CHR}, \@target_info);
			}

			$CUR_TARGET  = 0;
			$CUR_CHR     = $CHR;
			@target_info = @{ $CHR_TARGET{$CHR} };

			#initialize the array of hash when starts a new chromsome
			foreach my $i ( 0 .. $#target_info ) {
				my %CUR_HASH = ();
				push( @TARGET_BASE, \%CUR_HASH );
			}
		}

		#croak "chr name does not match $!" unless defined($target_info);
		#the chr name may not in the target file
		#		next unless defined(@target_info);
		next unless ( @target_info > 0 );
		while ( defined( $target_info[ $CUR_TARGET + 1 ] )
			&& $POS > $target_info[$CUR_TARGET]->[1] )
		{
			$CUR_TARGET += 1;
		}
		$FIRST = $target_info[$CUR_TARGET]->[0];
		$LAST  = $target_info[$CUR_TARGET]->[1];
		if ( $POS < $FIRST || $POS > $LAST ) {
			next;
		}
		else {
			$CHR_COUNT{$CUR_CHR}->[$CUR_TARGET] += 1;
			$TARGET_BASE[$CUR_TARGET]->{$POS}   += 1;

			#make sure overlapped targets get counted
			my $NEXT_TARGET = $CUR_TARGET + 1;
			while ( defined( $target_info[$NEXT_TARGET] )
				&& $POS > $target_info[$NEXT_TARGET]->[0] )
			{
				if ( $POS < $target_info[$NEXT_TARGET]->[1] ) {
					$CHR_COUNT{$CUR_CHR}->[$NEXT_TARGET] += 1;
					$TARGET_BASE[$NEXT_TARGET]->{$POS}   += 1;
				}
				$NEXT_TARGET += 1;
			}
		}
	}
	#do not forget the last chromosome
	if ( @TARGET_BASE > 0 ) {
		update_count_pois(\@TARGET_BASE, $CHR_COUNT{$CUR_CHR}, $CHR_COUNT_POIS{$CUR_CHR}, \@target_info);
	}
	return %CHR_COUNT_POIS;
}

sub update_count_pois {
	my $ref_TARGET_BASE = shift;	#an array of hash
	my $ref_CUR_CHR_COUNT = shift;	#an array of original count
	my $ref_CUR_CHR_COUNT_POIS = shift;	#an array of updated count
	my $ref_target_info = shift;	#an array of array

	return unless (defined($ref_TARGET_BASE) & defined($ref_CUR_CHR_COUNT) & defined($ref_CUR_CHR_COUNT_POIS) & defined($ref_target_info));

	my $target_num = scalar(@{$ref_TARGET_BASE}) - 1;

	foreach my $i ( 0 .. $target_num ) {
		next unless defined $ref_TARGET_BASE->[$i];
		my %CUR_HASH = %{$ref_TARGET_BASE->[$i]};
		my @CUR_HASH_KEY = keys(%CUR_HASH);
		my $key_num = scalar @CUR_HASH_KEY;
		if( $key_num > 0) {
			#review the targets and apply poisson
			my $size = $ref_target_info->[$i]->[1] - $ref_target_info->[$i]->[0];
#			my $lambda = $ref_CUR_CHR_COUNT->[$i] / $size;
			my $zero = ($size - $key_num) / $size;
			my $lambda = $zero < 0.0001 ? 9.21 : -log($zero);
			my $v = qpois( 0.9, $lambda );
			$v = 1 if $v == 0;
			my $sum      = 0;
			foreach my $k ( @CUR_HASH_KEY ) {
				$sum += $CUR_HASH{$k} < $v ? $CUR_HASH{$k} : $v;
				#for debug use
#				if($CUR_HASH{$k} > $v) {
#					print "$k\t$CUR_HASH{$k}\t$v\n";
#				}
			}
			$ref_CUR_CHR_COUNT_POIS->[$i] = $sum;
		}
		delete $ref_TARGET_BASE->[$i];
	}
}

sub qpois {
	my $cutoff = shift;
	my $lambda = shift;
	my $e      = 2.71828;
	my $p      = $e**( log($cutoff) + $lambda );
	my $accum  = 0;
	my $k      = 0;
	while ( $accum < $p ) {
		my $a = $lambda**$k;
		my $b = fac($k);
		$accum += ( $a / $b );
		$k++;
	}
	return $k - 1;
}

sub fac {
	my $n = shift;

	if ( $n < 2 ) {
		return 1;
	}
	else {
		return $n * fac( $n - 1 );
	}
}

sub slide_window_on_target {

	my $WIN_SIZE = shift || 50;
	my $IN       = shift || *STDIN;
	my $STEP_SIZE = $WIN_SIZE / 2;

	my $CHR   = "";
	my $POS   = 0;
	my $FIRST = 0;
	my $LAST  = 0;

	my $CUR_TARGET = 0;
	my $CUR_CHR    = "";
	my $OFF_TARGET = 0;

	#initialize CHR_COUNT hash table to zero
	foreach my $key ( keys %CHR_TARGET ) {
		my @value = @{ $CHR_TARGET{$key} };
		foreach my $i ( 0 .. $#value ) {
			my $WIN_NO = ( $value[$i]->[1] - $value[$i]->[0] ) / $STEP_SIZE;
			foreach my $ii ( 0 .. $WIN_NO ) {
				$CHR_COUNT{$key}->[$i]->[$ii] = 0;
			}
		}
	}

	#to save de-reference time
	my $target_info = ();
	while (<$IN>) {
		( my $QNAME, my $FLAG, $CHR, $POS, my $MAPQ, my $CIGAR, my $REST ) =
		  split /\t/, $_, 7;

		#only process the first 2 chr in debug mode
		$CHR =~ s/chr//;

		#we don't want duplicated, unmapped and Mitochodia reads
		next unless ( $FLAG < 1024 ) && ( $CIGAR ne "*" );
		next if $CHR =~ /^M/;

		if ( $CUR_CHR ne $CHR ) {
			$CUR_TARGET  = 0;
			$CUR_CHR     = $CHR;
			$target_info = $CHR_TARGET{$CHR};
		}

		#croak "chr name does not match $!" unless defined($target_info);
		#the chr name may not in the target file
		next unless defined($target_info);
		while ( defined( $target_info->[ $CUR_TARGET + 1 ] )
			&& $POS > $target_info->[$CUR_TARGET]->[1] )
		{
			$CUR_TARGET += 1;
		}
		$FIRST = $target_info->[$CUR_TARGET]->[0];
		$LAST  = $target_info->[$CUR_TARGET]->[1];
		if ( $POS < $FIRST || $POS > $LAST ) {
			$OFF_TARGET += 1;
			next;
		}
		else {
			my $WIN_NO = int( ( $POS - $FIRST ) / $STEP_SIZE );
			$CHR_COUNT{$CUR_CHR}->[$CUR_TARGET]->[$WIN_NO]       += 1;
			$CHR_COUNT{$CUR_CHR}->[$CUR_TARGET]->[ $WIN_NO - 1 ] += 1
			  unless ( $WIN_NO == 0 );

			#make sure overlapped targets get counted
			my $NEXT_TARGET = $CUR_TARGET + 1;
			while ( defined( $target_info->[$NEXT_TARGET] )
				&& $POS > $target_info->[$NEXT_TARGET]->[0] )
			{
				if ( $POS < $target_info->[$NEXT_TARGET]->[1] ) {
					my $NEXT_FIRST = $target_info->[$NEXT_TARGET]->[0];
					$WIN_NO = int( ( $POS - $NEXT_FIRST ) / $STEP_SIZE );
					$CHR_COUNT{$CUR_CHR}->[$NEXT_TARGET]->[$WIN_NO]       += 1;
					$CHR_COUNT{$CUR_CHR}->[$NEXT_TARGET]->[ $WIN_NO - 1 ] += 1
					  unless ( $WIN_NO == 0 );
				}
				$NEXT_TARGET += 1;
			}
		}
	}

	#	return $OFF_TARGET;
}

sub parse_window_on_target {
	print "Chromosome\tStart\tEnd\tWindow\tReadCount\n";
	my $ProbeID     = 0;
	my @old_keys    = keys %CHR_TARGET;
	my @sorted_keys = sort_hash_keys( \@old_keys );
	foreach my $key (@sorted_keys) {
		my @value = @{ $CHR_TARGET{$key} };
		foreach my $i ( 0 .. $#value ) {
			my $first = $value[$i]->[0];
			my $last  = $value[$i]->[1];
			next unless defined( $CHR_COUNT{$key}->[$i] );
			my @count = @{ $CHR_COUNT{$key}->[$i] };

			#			my $median_c = calculate_median(\@count);
			#			my $POSITION = $value[$i]->[2];
			#			$ProbeID += 1;
			#			print "$ProbeID\t$key\t$POSITION\t$median_c\n";
			foreach my $ii ( 0 .. $#count ) {
				my $c = $count[$ii];
				next unless defined($c);
				print "$key\t$first\t$last\t$ii\t$c\n";
			}
		}
	}
}

sub rmdup_on_target {
	my $win_threshold = shift;

	my $IN        = shift || *STDIN;
	my $CUR_CHR   = "";
	my $CUR_START = 0;
	my $CUR_END   = 0;
	my $sum       = 0;
	print "Chromosome\tPosition\tReadCount\n";
	while (<$IN>) {
		chomp();
		my ( $chr, $start, $end, $win, $count ) = split /\t/, $_, 5;
		next if ( $chr =~ /^Chromosome/ );
		if ( $CUR_CHR eq "" ) {
			$CUR_CHR   = $chr;
			$CUR_START = $start;
			$CUR_END   = $end;
		}
		if ( $CUR_CHR ne $chr || $CUR_START != $start || $CUR_END != $end ) {
			my $position = ( $CUR_START + $CUR_END ) / 2;
			print "$CUR_CHR\t$position\t$sum\n";
			$sum       = 0;
			$CUR_CHR   = $chr;
			$CUR_START = $start;
			$CUR_END   = $end;
		}
		$sum += $count if ( $count < $win_threshold );
	}
	if ( $sum > 0 ) {
		my $position = ( $CUR_START + $CUR_END ) / 2;
		print "$CUR_CHR\t$position\t$sum\n";
	}
}

sub output_read_count {
	my $SAM      = shift || *STDIN;    #croak "No control file specified $!";
	my $LOG_FILE = shift || *STDOUT;

	my %CHR_COUNT = get_on_target_count($SAM);
#	my %CHR_COUNT = poisson_on_target_count($SAM);
	print $LOG_FILE "ProbeID\tChromosome\tPosition\tReadCount\n";
	my $ProbeID = 0;

	#re-sort hash keys
	my @old_keys    = keys %CHR_COUNT;
	my @sorted_keys = sort_hash_keys( \@old_keys );
	foreach my $key (@sorted_keys) {
		my @value = @{ $CHR_COUNT{$key} };
		foreach my $i ( 0 .. $#value ) {
			my $POSITION = $CHR_TARGET{$key}->[$i]->[2];
			$ProbeID += 1;
			print $LOG_FILE "$ProbeID\t$key\t$POSITION\t$value[$i]\n";
		}
	}
	return %CHR_COUNT;
}

sub sort_read_counts {
	my $CONTROL = shift || *STDIN;
	my $OUTPUT  = shift || *STDOUT;
	my ( $control_median, %CHR_COUNT ) = load_read_counts($CONTROL);

	print $OUTPUT "ProbeID\tChromosome\tPosition\tReadCount\n";
	my $ProbeID = 0;

	#re-sort hash keys
	my @old_keys    = keys %CHR_COUNT;
	my @sorted_keys = sort_hash_keys( \@old_keys );
	foreach my $key (@sorted_keys) {
		my @value = @{ $CHR_COUNT{$key} };
		foreach my $i ( 0 .. $#value ) {
			my $pos = $value[$i]->[2];
			my $rc  = $value[$i]->[3];
			$ProbeID += 1;
			print $OUTPUT "$ProbeID\t$key\t$pos\t$rc\n";
		}
	}
}

sub calculate_log2_ratio {

	my $CONTROL   = shift || *STDIN;    #croak "No control file specified $!";
	my $TUMOR     = shift || *STDIN;    #croak "No tumor file specified $!";
	my $LOG_FILE  = shift || *STDOUT;
	my $min_count = shift || 100;

	my ( $control_median, %CHR_COUNT_CONTROL ) = load_read_counts($CONTROL);
	my ( $tumor_median,   %CHR_COUNT_TUMOR )   = load_read_counts($TUMOR);

	print $LOG_FILE "ProbeID\tChromosome\tPosition\tLogRatio\n";

	my $ProbeID = 0;

	my @old_keys    = keys %CHR_COUNT_CONTROL;
	my @sorted_keys = sort_hash_keys( \@old_keys );

	foreach my $key (@sorted_keys) {
		my @control_value = @{ $CHR_COUNT_CONTROL{$key} };
		my @tumor_value   = @{ $CHR_COUNT_TUMOR{$key} };
		if ( $#control_value == $#tumor_value ) {
			foreach my $i ( 0 .. $#control_value ) {
				my $control_count = $control_value[$i]->[3];
				my $tumor_count   = $tumor_value[$i]->[3];

				#				if ( $control_count == 0 ) {
				#					$control_count = 0.001;
				#				}
				#				if ( $tumor_count == 0 ) {
				#					$tumor_count = 0.001;
				#				}
				if ( $control_count < $min_count || $tumor_count < $min_count )
				{
					next;
				}
				$tumor_count   = $tumor_count / $tumor_median;
				$control_count = $control_count / $control_median;
				my $LOG_2    = log( $tumor_count / $control_count ) / log(2);
				my $POSITION = $CHR_COUNT_CONTROL{$key}->[$i]->[2];
				$ProbeID += 1;
				print $LOG_FILE "$ProbeID\t$key\t$POSITION\t$LOG_2\n";
			}
		}
	}
}

sub load_read_counts {
	my $READ_COUNT  = shift;
	my %CHR_COUNT   = ();
	my @COUNT_ARRAY = ();
	while (<$READ_COUNT>) {
		chomp;
		my ( $id, $chr, $pos, $rc ) = split /\t/;
		if ( $id eq "ProbeID" ) {
			next;
		}
		push( @COUNT_ARRAY, $rc );
		my $array_ref = $CHR_COUNT{$chr};
		if ( not defined($array_ref) ) {
			$CHR_COUNT{$chr} = [ [ $id, $chr, $pos, $rc ] ];
		}
		else {
			push( @{ $CHR_COUNT{$chr} }, [ $id, $chr, $pos, $rc ] );
		}
	}
	my $median = calculate_median( \@COUNT_ARRAY );
	return ( $median, %CHR_COUNT );
}

sub diff_coverage {
	my $DIFF  = shift || croak "No diff_ratio_sample file specified $!";
	my $COUNT = shift || croak "No read_counts_sample file specified $!";
	my $diff_coverage = shift || *STDOUT;

	my %CHR_RATIO      = load_read_counts($DIFF);
	my %CHR_READ_COUNT = load_read_counts($COUNT);

	print $diff_coverage "DIFF\tCOVERAGE\n";
	foreach my $key ( keys %CHR_RATIO ) {
		my @value        = @{ $CHR_RATIO{$key} };
		my @count_value  = @{ $CHR_READ_COUNT{$key} };
		my @target_value = @{ $CHR_TARGET{$key} };
		foreach my $i ( 0 .. $#value ) {
			my $diff     = $value[$i]->[3];
			my $counts   = $count_value[$i]->[3];
			my $size     = $target_value[$i]->[1] - $target_value[$i]->[0];
			my $coverage = $counts / $size;
			printf $diff_coverage "%g", $diff;
			print $diff_coverage "\t";
			printf $diff_coverage "%g", $coverage;
			print $diff_coverage "\n";

		}
	}
}

sub two_sample_compare {
	my $THRESHOLD = 0.4;

	my $SAMPLE1 = shift || croak "No diff_ratio_sample file specified $!";
	my $SAMPLE2 = shift || croak "No diff_ratio_sample file specified $!";
	my $SAMPLE2_WGS = shift
	  || croak "No second diff_ratio_sample file specified $!";
	my $SAMPLE2_capture = shift
	  || croak "No second diff_ratio_sample file specified $!";
	my $WGS_LOG_FILE = shift
	  || croak "No diff_ratio_output file specified $!";
	my $capture_LOG_FILE = shift
	  || croak "No diff_ratio_output file specified $!";

	#	my $diff_diff = shift || *STDOUT;

	my $SMALL_DIFF_1 = 0;
	my $SMALL_DIFF_2 = 0;

	my $start      = $SAMPLE1->getpos();
	my %CHR_RATIO1 = load_read_counts($SAMPLE1);
	if ( $SAMPLE1 eq $SAMPLE2 ) {
		$SAMPLE2->setpos($start);
	}
	my %CHR_RATIO2  = load_read_counts($SAMPLE2);
	my %CHR_RATIO21 = load_read_counts($SAMPLE2_WGS);
	my %CHR_RATIO22 = load_read_counts($SAMPLE2_capture);

	print $WGS_LOG_FILE "ProbeID\tChromosome\tPosition\tLogRatio\n";
	print $capture_LOG_FILE "ProbeID\tChromosome\tPosition\tLogRatio\n";

	#	print $diff_diff "DIFF1\tDIFF2\n";

	foreach my $key ( keys %CHR_RATIO1 ) {
		my @value = @{ $CHR_RATIO1{$key} };
		foreach my $i ( 0 .. $#value ) {
			my $diff1 = $value[$i]->[3];
			if ( abs($diff1) < $THRESHOLD ) {
				$SMALL_DIFF_1 += 1;
				my $diff2 = $CHR_RATIO2{$key}->[$i]->[3];
				if ( abs($diff2) < $THRESHOLD ) {
					$SMALL_DIFF_2 += 1;
				}
				my $LOG_2    = $CHR_RATIO21{$key}->[$i]->[3];
				my $POSITION = $CHR_RATIO21{$key}->[$i]->[2];
				my $ProbeID  = $CHR_RATIO21{$key}->[$i]->[0];
				print $WGS_LOG_FILE "$ProbeID\t$key\t$POSITION\t$LOG_2\n";

				$LOG_2    = $CHR_RATIO22{$key}->[$i]->[3];
				$POSITION = $CHR_RATIO22{$key}->[$i]->[2];
				$ProbeID  = $CHR_RATIO22{$key}->[$i]->[0];
				print $capture_LOG_FILE "$ProbeID\t$key\t$POSITION\t$LOG_2\n";

				#				printf $diff_diff "%g", $diff1;
				#				print $diff_diff "\t";
				#				printf $diff_diff "%g", $diff2;
				#				print $diff_diff "\n";
			}
		}
	}
	my $no_target = 92685;
	my $percent   = $SMALL_DIFF_1 / $no_target * 100;
	print "Number of small diff in sample 1 is $SMALL_DIFF_1 ($percent\%)\n";
	$percent = $SMALL_DIFF_2 / $no_target * 100;
	print "Number of same probe in sample 2 is $SMALL_DIFF_2 ($percent\%)\n";

}

sub calculate_ratio_diff {
	my $CONTROL_CAPTURE = shift || croak "No control file specified $!";
	my $TUMOR_CAPTURE   = shift || croak "No tumor file specified $!";
	my $CONTROL_WGS     = shift;
	my $TUMOR_WGS       = shift;

	my %CAPTURE_RATIO = get_on_target_count( $CONTROL_CAPTURE, $TUMOR_CAPTURE );
	my %WGS_RATIO     = get_on_target_count( $CONTROL_WGS,     $TUMOR_WGS );

	my %CHR_RATIO_DIFF = ();

}

sub seperate {
	my $IN         = shift || *STDIN;
	my $OFF_TARGET = shift || *STDOUT;
	my $ON_TARGET  = shift || *STDOUT;

	my $CHR   = "";
	my $POS   = 0;
	my $FIRST = 0;
	my $LAST  = 0;

	my $CUR_TARGET = 0;
	my $CUR_CHR    = 0;

	my $ON_TARGET_NO  = 0;
	my $OFF_TARGET_NO = 0;

	while (<$IN>) {
		chomp;
		( my $QNAME, my $FLAG, $CHR, $POS, my $MAPQ, my $CIGAR, my $REST ) =
		  split /\t/, $_, 7;

        # added by Yong Chen start

        # $POS is the start position of one read.
        # if(length($CHR) < 3) {  # some sequencing platforms may mark its chromosome without 'chr' as prefix.
        #     $CHR = 'chr'.$CHR;
        # }
        # added by Yong Chen end

		# if ( not( $CHR =~ m/^chr/ ) ) {
		# 	next;
		# }

		# else {
		# 	$CHR =~ s/chr//;
		# }

        if ( $CHR =~ m/^chr/ ){
            $CHR =~ s/chr//;
        }

		#we don't want duplicated, unmapped and Mitochodia reads
		next if ( $CIGAR eq "*" );
		next if $CHR =~ /^M/;

		if ( $CUR_CHR ne $CHR ) {
			$CUR_TARGET = 0;
			$CUR_CHR    = $CHR;
		}
		my $target_info = $CHR_TARGET{$CHR};
		while ( $POS > $target_info->[$CUR_TARGET]->[1] ) {
			if ( not defined( $target_info->[ $CUR_TARGET + 1 ] ) ) {
				last;
			}
			$CUR_TARGET += 1;
		}
		$FIRST = $target_info->[$CUR_TARGET]->[0];
		$LAST  = $target_info->[$CUR_TARGET]->[1];
		if ( $POS < $FIRST || $POS > $LAST ) {
			if ( $FLAG < 1024 ) {
				$OFF_TARGET_NO += 1;
				print $OFF_TARGET "-$POS\n";
			}
		}
		else {
			$ON_TARGET_NO += 1;
			print $ON_TARGET "$POS\n";
		}
	}
	return $OFF_TARGET_NO, $ON_TARGET_NO;
}

sub seperate_by_chr {
	#my $IN  = shift || *STDIN;
	my $OUT = shift || *STDOUT;
	my $IN  = shift || *STDIN;

	open (my $INFILE, $IN);
	open (my $OUTFILE, "$OUT/tmp");

	my $CHR   = "";
	my $POS   = 0;
	my $FIRST = 0;
	my $LAST  = 0;

	my $CUR_TARGET = 0;
	my $CUR_CHR    = 0;

	my $ON_TARGET_NO  = 0;
	my $OFF_TARGET_NO = 0;

	while (<$INFILE>) {
		chomp;
		( my $QNAME, my $FLAG, $CHR, $POS, my $MAPQ, my $CIGAR, my $REST ) =
		  split /\t/, $_, 7;

		if(length($CHR) < 3) {
		    $CHR = 'chr'.$CHR;
		}

		if ( not( $CHR =~ m/^chr/ ) ) {
			next;
		}

		else {
			$CHR =~ s/chr//;
		}

		#we don't want unmapped and Mitochodia reads
		next if ( $CIGAR eq "*" );
		next if $CHR =~ /^M/;

		if ( $CUR_CHR ne $CHR ) {
			$CUR_TARGET = 0;
			$CUR_CHR    = $CHR;
			close($OUTFILE);
			open( $OUTFILE, '>', "$OUT/chr$CUR_CHR" );
		}

		my $target_info = $CHR_TARGET{$CHR};

        if ( not( defined( $POS ) ) ) {
            $POS = 0;
        }

        if ( not( defined( $CUR_TARGET ) ) ) {
            $CUR_TARGET = 0;
        }

        if ( not defined($target_info) ) {
            # print $CHR;
            next;
        }

		while ( $POS > $target_info->[$CUR_TARGET]->[1] ) {
            $CUR_TARGET += 1;
			if ( not defined( $target_info->[ $CUR_TARGET ] ) ) {
                $CUR_TARGET -= 1;
				last;
			}
            if ( not defined( $target_info->[$CUR_TARGET]->[1] ) ) {
                $target_info->[$CUR_TARGET]->[1] = 0;
            }
		}

		$FIRST = $target_info->[$CUR_TARGET]->[0];
		$LAST  = $target_info->[$CUR_TARGET]->[1];

        if ( not( defined( $FIRST ) ) ) {
            $FIRST = 0;
        }

        if ( not( defined( $LAST ) ) ) {
            $LAST = 0;
        }

		if ( $POS < $FIRST || $POS > $LAST ) {
			if ( $FLAG < 1024 ) {
				$OFF_TARGET_NO += 1;
				print $OUTFILE "-$POS\n";
			}
		}
		else {
			$ON_TARGET_NO += 1;
			print $OUTFILE "$POS\n";
		}
	}
	close($OUT);
	return $OFF_TARGET_NO, $ON_TARGET_NO;
}

sub exclude_targets {
	my $IN         = shift || *STDIN;
	my $OFF_TARGET = shift || *STDOUT;
	my $ON_TARGET  = shift || *STDOUT;

	my $CHR   = "";
	my $POS   = 0;
	my $FIRST = 0;
	my $LAST  = 0;

	my $CUR_TARGET = 0;
	my $CUR_CHR    = 0;

	my $ON_TARGET_NO  = 0;
	my $OFF_TARGET_NO = 0;

	#	remind_time("Start to exclude on_target reads\n");

	while (<$IN>) {
		chomp;
		( my $QNAME, my $FLAG, $CHR, $POS, my $MAPQ, my $CIGAR, my $REST ) =
		  split /\t/, $_, 7;

		if ( not( $CHR =~ m/^chr/ ) ) {
			next;
		}

		else {
			$CHR =~ s/chr//;
		}

		#we don't want duplicated, unmapped and Mitochodia reads
		next if ( $CIGAR eq "*" ); #( $FLAG < 1024 ) &&
		next if $CHR =~ /^M/;

		if ( $CUR_CHR ne $CHR ) {
			$CUR_TARGET = 0;
			$CUR_CHR    = $CHR;
		}
		my $target_info = $CHR_TARGET{$CHR};
		while ( $POS > $target_info->[$CUR_TARGET]->[1] ) {
			if ( not defined( $target_info->[ $CUR_TARGET + 1 ] ) ) {
				last;
			}
			$CUR_TARGET += 1;
		}
		$FIRST = $target_info->[$CUR_TARGET]->[0];
		$LAST  = $target_info->[$CUR_TARGET]->[1];
		if ( $POS < $FIRST || $POS > $LAST ) {
			$OFF_TARGET_NO += 1;
			print $OFF_TARGET "$_\n";
		}
		else {
			$ON_TARGET_NO += 1;

#			print $ON_TARGET "$_\n";
		}
	}
	return $OFF_TARGET_NO, $ON_TARGET_NO;
}

sub minimal_sam {
	my $IN  = shift;
	my $OUT = shift;
	while (<$IN>) {
		chomp;
		my (
			$QNAME, $FLAG, $CHR,   $POS, $MAPQ, $CIGAR,
			$MRNM,  $MPOS, $ISIZE, $SEQ, $QUAL, $OPTIONAL
		  )
		  = split /\t/, $_, 12;

		if ( $CHR =~ m/^chr/ ) {
			$_ =
"$QNAME\t$FLAG\t$CHR\t$POS\t$MAPQ\t$CIGAR\t$MRNM\t$MPOS\t$ISIZE\t$SEQ\t$QUAL";
		}
		print $OUT "$_\n";
	}
}

sub random_exclusion {

	my $IN  = shift || croak "Specify input stream for random_exclusion $!";
	my $P   = shift || 0.01;
	my $OUT = shift || *STDOUT;

	while (<$IN>) {
		next unless $P > rand();
		print $OUT $_;
	}
}

sub write_log {
	my %RATIO = shift;
	open( my $LOG, '>', "log" );
	print $LOG "ProbeID\tChromosome\tPosition\tLogRatio\n";
	close($LOG);
}

sub remind_time {
	my (
		$second,     $minute,    $hour,
		$dayOfMonth, $month,     $yearOffset,
		$dayOfWeek,  $dayOfYear, $daylightSavings
	  )
	  = localtime();
	print "$hour:$minute:$second\n";
	my $message = shift;
	print $message;
}

sub calculate_median {
	my $ARRAY  = shift;
	my @SORT   = sort { $a <=> $b } @{$ARRAY};
	my $MEDIAN = 0;
	$MEDIAN =
	  $SORT[ int( $#SORT / 2 ) ]
	  ;   # In a good array this is close enough to the median for our purposes.
	return $MEDIAN;
}

sub sort_hash_keys {
	my $ARRAY = shift;
	my @CHR   = @{$ARRAY};

	#	foreach my $name ( @{$ARRAY} ) {
	#		my $no_prefix = substr $name, 3;
	#		push( @CHR, $no_prefix );
	#	}
	my @SORT =
	  sort { isdigit($a) && isdigit($b) ? $a <=> $b : $a cmp $b } @CHR;

	#	foreach my $index ( 0 .. $#SORT ) {
	#		$SORT[$index] = join( '', "chr", $SORT[$index] );
	#	}
	return @SORT;
}

1;

