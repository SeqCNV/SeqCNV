#include <stdint.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;
const unsigned maxl = 250 * 1000000;

struct  Block{
	unsigned	l, r;
	unsigned	t0, c0;
	unsigned	t1, c1;
};

bool    bin2blk(string  T, string  C, string  O){
	vector<uint16_t>    t0(maxl), c0(maxl), t1(maxl), c1(maxl);
	int    n;
	ifstream    ft(T.c_str());  if (!ft) return  false;
	for (ft >> n; !ft.eof(); ft >> n){
		if (n > 0){ if (t0[n] < 65535)	t0[n]++; else    return  false; }
		else{ if (t1[-n] < 65535)	t1[-n]++; else    return  false; }
	}
	ft.close();
	ifstream    fc(C.c_str());  if (!fc) return  false;
	for (fc >> n; !fc.eof(); fc >> n){
		if (n > 0){ if (c0[n] < 65535)	c0[n]++; else    return  false; }
		else{ if (c1[-n] < 65535)	c1[-n]++; else    return  false; }
	}
	fc.close();

    ofstream    fo(O.c_str(), ios::binary);
    n = 19811031; fo.write((const char*)&n, sizeof(unsigned));
    n = 0;
	for (unsigned i = 0; i < maxl; i++){
        if (t0[i] || c0[i] || t1[i] || c1[i]) {
            n++;
        }
	}
	fo.write((const char*)&n, sizeof(unsigned));
	for (unsigned i = 0; i < maxl; i++) {
        if (t0[i] || c0[i] || t1[i] || c1[i]) {
    		Block   temp;	temp.l = i;   temp.r = i;
    		temp.t0 = t0[i];    temp.c0 = c0[i];	temp.t1 = t1[i];    temp.c1 = c1[i];
    		fo.write((const char*)&temp, sizeof(Block));
    	}
    }
	fo.close();
	cout << n << endl;
	return true;
}

int main(int	ac, char	**av){
	string  f[3];
	if (ac < 4){
		cout << "enter target file name:\t";  cin >> f[0];
		cout << "enter control file name:\t";	cin >> f[1];
		cout << "enter output file name:\t";  cin >> f[2];
	}
	else{ f[0] = av[1]; f[1] = av[2]; f[2] = av[3]; }
	bin2blk(f[0], f[1], f[2]);
	return  0;
}
