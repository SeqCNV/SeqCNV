#include    <algorithm>
#include    <iostream>
#include    <fstream>
#include    <vector>
#include    <cfloat>
#include    <cmath>
using   namespace   std;

struct  Block{
	unsigned    l,  r;
	unsigned    t0,  c0;
	unsigned    t1,  c1;
	bool    operator()(Block    X,  Block   Y){ return  X.l<Y.l;    }
};

class   SeqCNV{
private:
	unsigned	bn;
	vector<Block>	block;
	inline  double	like(unsigned	T,	unsigned	C);
public:
	double	penalty;
	int tumorReadsCount;
	int controlReadsCount;
	float librarySize;

	bool    load(string	F);
	void    best(void);
	void    save(string	F);
};

double	SeqCNV::like(unsigned  T,  unsigned    C){
	if(T&&C){
		float p = float(librarySize * T) / (librarySize*T+C);
		return  librarySize * T*logf(p)+C*logf(1-p);
	}
	else    return  0;
}

bool    SeqCNV::load(string	F){
	ifstream    fi(F.c_str(),	ios::binary);   if(!fi) return  false;
	fi.read((char*)&bn,  sizeof(unsigned));  if(bn!=19811031) return  false;
	fi.read((char*)&bn,  sizeof(unsigned));	block.resize(bn);
	fi.read((char*)&block[0],	sizeof(Block)*bn);
	fi.close();

	if(penalty<0){
		unsigned    tn=0,   cn=0;
		for(unsigned    i=0;    i<bn;   i++){   tn+=block[i].t0+block[i].t1; cn+=block[i].c0+block[i].c1; }
		penalty=log(tn+cn);	cout<<"penalty\t"<<penalty<<endl;
	}
	cout<<"input\t"<<bn<<endl;
	return  true;
}

void    SeqCNV::best(void){
	vector<unsigned>    bp(bn);
	vector<double>    bs(bn);
	vector<Block>   result;
	double    cuts= M_E*penalty;

	bp[0]=0;	bs[0]=like(block[0].t0,	block[0].c0)+like(block[0].t1,	block[0].c1)-0.5*penalty;
	for(unsigned    i=1;    i<bn;   i++){
   		double    s,	tbs=-FLT_MAX;
  		unsigned    tbp=0,	t0=0,	c0=0,	t1=0,	c1=0;
		for(unsigned    j=i;  j<=i;   j--){
			t0+=block[j].t0;   c0+=block[j].c0;
			t1+=block[j].t1;   c1+=block[j].c1;
			s=j	?	like(t0,c0)+like(t1,c1)+bs[j-1]-penalty   :   like(t0,c0)+like(t1,c1)-penalty;
			if(s>tbs){	tbs=s;  tbp=j;	}
			if(s+cuts<tbs)  break;
		}
		bp[i]=tbp;	bs[i]=tbs;
		if(!(i%10000)){	cout<<i/1000<<"k\r";    cout.flush();   }
	}
	for(unsigned    i=bn-1;	i<bn;	i=bp[i]-1){
		Block   temp;	temp.r=block[i].r;   temp.l=block[bp[i]].l; temp.t0=temp.c0=temp.t1=temp.c1=0;
		for(unsigned    j=bp[i];    j<=i;   j++){
			temp.t0+=block[j].t0; temp.c0+=block[j].c0;
			temp.t1+=block[j].t1; temp.c1+=block[j].c1;
		}
		result.push_back(temp);
	}
	sort(result.begin(),	result.end(), Block());
	block=result;
}

void    SeqCNV::save(string	F){
	ofstream    fo(F.c_str(),	ios::binary);
	bn=19811031;	fo.write((const	char*)&bn,  sizeof(unsigned));
	bn=block.size();fo.write((const	char*)&bn,  sizeof(unsigned));
	fo.write((const	char*)&block[0],	sizeof(Block)*bn);
	fo.close();
	cout<<"output\t"<<bn<<endl;
}

int main(int    ac, char**  av){
	SeqCNV  s;
	string  f[5];

	cout<<"\nWelcome to SeqCNV!\n©Fudan University\n©Baylor College of Medcine\n\n";
	if(ac<6){
		cout<<"enter input file name:\t";  cin>>f[0];
		cout<<"enter output file name:\t";	cin>>f[1];
		cout<<"enter block penalty:\t"; cin>>f[2];
		cout<<"enter tumor reads count:\t"; cin>>f[3];
		cout<<"enter control reads count:\t"; cin>>f[4];
	}
	else{
		f[0]=av[1];
		f[1]=av[2];
		f[2]=av[3];
		f[3]=av[4];
		f[4]=av[5];
	}
	s.penalty=atof(f[2].c_str());
	unsigned t=clock();
	s.tumorReadsCount=atoi(f[3].c_str());
	s.controlReadsCount=atoi(f[4].c_str());
	float libsize = float(s.controlReadsCount)/float(s.tumorReadsCount);
    s.librarySize = 1.0;
	if (libsize <= 0.7 || libsize >= 1.3){
		s.librarySize = libsize;
	}
	s.load(f[0]);
	s.best();
	s.save(f[1]);
	cout<<(double)(clock()-t)/CLOCKS_PER_SEC<<" seconds\n\n";
	return  0;
}

