#!/usr/bin/perl -w

#File: run_CNV.pl
#Purpose: Runs a CNV calling algorithm for given case and control samples.

use Cwd;
use strict;
use Getopt::Long;

use vars qw( $opt_help $opt_toolpath $opt_control $opt_case $opt_out_dir $opt_target );

if (!GetOptions("help|h", "toolpath|p:s", "control|c:s", "case|t:s", "out_dir|o:s", "target|r:s",)) {
    &usage(1);
}

if ($opt_help) {
    &usage(0);
}

my $tumor = $opt_case;
my $control = $opt_control;
my $outdir = $opt_out_dir;
my $target = $opt_target;
my $toolpath = $opt_toolpath;

#print the command that is run (STDOUT)
print("mkdir $outdir/control $outdir/tumor $outdir/blk $outdir/tsv $outdir/report\n
perl -I $toolpath $toolpath/separate_chrom.pl -f $target -c $control -t $tumor -o $outdir\n
perl -I $toolpath $toolpath/run_seqcnv_allchr.pl -p $toolpath -s $outdir\n
perl -I $toolpath $toolpath/report_from_tsv.pl -s $outdir/tsv/ -o $outdir/report/CNV_report.txt -e 3.20\n");
# print("echo \"mkdir $outdir/control $outdir/tumor $outdir/blk $outdir/tsv $outdir/report
# perl $toolpath/separate_chrom.pl -f $target -c $control -t $tumor -o $outdir
# perl $toolpath/run_seqcnv_allchr.pl -p $toolpath -s $outdir
# perl $toolpath/report_from_tsv.pl -s $outdir/tsv/ -o $outdir/report/CNV_report.txt -e 3.20\"\n");

#run the seqcnv procedure with four steps:
#	1. mkdir: Create output file structure.
#	2. separate_chrom.pl: Converts .bam input files into valid input for seqcnv (seperate files for each chromosome).
#	3. run_seqcnv_allchr.pl: Runs the seqcnv algorithm on each chromsome of the samples.
#	4. report_from_tsv.pl: Combines and converts all output to a readable format.
system("mkdir $outdir/control $outdir/tumor $outdir/blk $outdir/tsv $outdir/report");
system("perl -I $toolpath $toolpath/separate_chrom.pl -f $target -c $control -t $tumor -o $outdir");
system("perl -I $toolpath $toolpath/run_seqcnv_allchr.pl -p $toolpath -s $outdir");
system("perl -I $toolpath $toolpath/report_from_tsv.pl -s $outdir/tsv/ -o $outdir/report/CNV_report.txt -e 3.20");

# system("echo \"mkdir $outdir/control $outdir/tumor $outdir/blk $outdir/tsv $outdir/report
# perl $toolpath/separate_chrom.pl -f $target -c $control -t $tumor -o $outdir
# perl $toolpath/run_seqcnv_allchr.pl -p $toolpath -s $outdir
# perl $toolpath/report_from_tsv.pl -s $outdir/tsv/ -o $outdir/report/CNV_report.txt -e 3.20\"\n");

sub usage {
    print "
Usage: perl
	-h Prints this message
	-p toolpath: [Required] The path to seqcnv tools (Required tools: separate_chrom.pl, run_seqcnv_allchr.pl, report_from_tsv.pl)
	-c control: [Required] A .bam file containing the control sample.
	-t case: [Required] A .bam file containg the case sample.
	-o out_dir: [Required] The directory for all output (should be seperate for each case/control pair).
	-r target: [Required] A .bed file contaning the capture target information.

";

    exit;
}

