#!/usr/bin/perl -w
use capture_filter;

use FileHandle;
use warnings;
use File::stat;
use Getopt::Long;
use List::Util qw(min);
use vars qw( $opt_help $opt_tsv $opt_out $opt_lbound $opt_ubound $opt_ext $opt_name);

# Read opts
if (
	!GetOptions(
		"help|h", "tsv|s:s", "out|o:s", "lbound|l:i", "ubound|u:i", "ext|e:s", "name|n:s",
	)
  )
{
	&usage(1);
}
if ($opt_help) {

	#  What to do when user needs help:  Default is usage statement
	&usage(0);
}

my @chrom = ("chr1", "chr2", "chr3", "chr4", "chr5", "chr6", "chr7", "chr8", "chr9", "chr10",
	     "chr11", "chr12", "chr13", "chr14", "chr15", "chr16", "chr17", "chr18", "chr19",
	     "chr20", "chr21", "chr22", "chrX", "chrY");

my $folder = $opt_tsv || ".";
my $lb = $opt_lbound || 0.6;
my $ub = $opt_ubound || 1.4;
open OUT, ">", $opt_out or die $!;
#print OUT "chr\tstart_pos\tendpos\tlength(kb)\tc_on\tt_on\tr_on\n";

#print "$folder/chr1.$opt_ext.tsv";

foreach my $c (@chrom) {

	open FILE, "$folder/$c.$opt_ext.tsv" or next;
	my $header = 1;
	while (<FILE>) {
		if ($header == 1) {
			$header = 0;
			next;
		}
		else {
			my @fields = split(/\t/, $_);
			if ($fields[8] ne "NA") {
				if (($fields[8] < $lb || $fields[8] > $ub) && $fields[3] > 0.01) {
					print OUT "$c\t$fields[1]\t$fields[2]\t$fields[3]\t$fields[4]\t$fields[5]\t$fields[8]\n";
				}
			}
		}
	}
}

sub usage {
	print "
Usage:
test seqcnv, report from tsv.
";
	exit;
}
