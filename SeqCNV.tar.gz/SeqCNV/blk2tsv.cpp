#include    <algorithm>
#include    <iostream>
#include    <fstream>
#include    <vector>
#include    <cfloat>
#include    <cmath>
using   namespace   std;
typedef unsigned    uint;
typedef float	fast;

struct  Block{
	uint    l,  r;
	uint    t0,  c0;
	uint    t1,  c1;
};

class   SeqCNV{
private:
	uint	bn;
	vector<Block>	block;
public:
	fast	ratio0,	ratio1;

	bool    load(string	F);
	void    save(string	F);
};

bool    SeqCNV::load(string	F){
	ifstream    fi(F.c_str(),	ios::binary);   if(!fi) return  false;
	fi.read((char*)&bn,  sizeof(uint));  if(bn!=19811031) return  false;
	fi.read((char*)&bn,  sizeof(uint));	block.resize(bn);
	fi.read((char*)&block[0],	sizeof(Block)*bn);
	fi.close();
	return  true;
}

void    SeqCNV::save(string	F){
	if(ratio0<0){
		uint    t=0,	c=0;
		for(uint    i=0;    i<bn;   i++){   t+=block[i].t0;  c+=block[i].c0;  }
		ratio0=(t+0.5)/(c+0.5);
	}
	if(ratio1<0){
		uint    t=0,	c=0;
		for(uint    i=0;    i<bn;   i++){   t+=block[i].t1;  c+=block[i].c1;  }
		ratio1=(t+0.5)/(c+0.5);
	}

	ofstream    fo(F.c_str());	fo.precision(3);	fo.setf(ios::fixed);
	fo<<bn<<" 6\tstart\tend\tsize(kb)\tt_on\tc_on\tt_off\tc_off\tr_on\tr_off\n";
	for(uint    i=0;    i<bn;   i++){
		fo<<"block_"<<i<<'\t'<<block[i].l<<'\t'<<block[i].r<<'\t'<<1e-3*(block[i].r-block[i].l+1)<<'\t';
		fo<<block[i].t0<<'\t'<<block[i].c0<<'\t'<<block[i].t1<<'\t'<<block[i].c1<<'\t';
		if(block[i].t0+block[i].c0)	fo<<(block[i].t0+0.5)/(block[i].c0+0.5)/ratio0<<'\t';
		else	fo<<"NA\t";
		if(block[i].t1+block[i].c1)	fo<<(block[i].t1+0.5)/(block[i].c1+0.5)/ratio1<<endl;
		else	fo<<"NA\n";
	}
	fo.close();
}

int main(int    ac, char**  av){
	SeqCNV  s;
	string  f[4];

	if(ac<5){
		cout<<"enter input file name:\t";  cin>>f[0];
		cout<<"enter output file name:\t";	cin>>f[1];
		cout<<"enter on target/control:\t"; cin>>f[2];
		cout<<"enter off target/control:\t"; cin>>f[3];
	}
	else{	f[0]=av[1]; f[1]=av[2]; f[2]=av[3];	f[3]=av[4];	}
	s.ratio0=atof(f[2].c_str());	s.ratio1=atof(f[3].c_str());
	s.load(f[0]);
	s.save(f[1]);
	return  0;
}

