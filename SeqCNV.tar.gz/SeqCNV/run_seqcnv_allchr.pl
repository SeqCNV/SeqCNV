#!/usr/bin/perl -w
use capture_filter;

use FileHandle;
use warnings;
use File::stat;
use Getopt::Long;
use List::Util qw(min);
use vars qw( $opt_help $opt_toolpath $opt_r_off $opt_r_on $opt_sample );

# Read opts
if (
	!GetOptions(
		"help|h", "toolpath|p:s", "r_off|f:s", "r_on|n:s", "sample|s:s"
	)
  )
{
	&usage(1);
}
if ($opt_help) {

	#  What to do when user needs help:  Default is usage statement
	&usage(0);
}

my @chrom = ("chr1", "chr2", "chr3", "chr4", "chr5", "chr6", "chr7", "chr8", "chr9", "chr10",
	     "chr11", "chr12", "chr13", "chr14", "chr15", "chr16", "chr17", "chr18", "chr19",
	     "chr20", "chr21", "chr22", "chrX", "chrY");

my $tool = $opt_toolpath;
my $command = "";
my $folder = $opt_sample || ".";
my $blk = "$folder/blk";

foreach my $c (@chrom) {

	my $name = $c;

	my $tumor_reads_count = 0;
	my $control_reads_count = 0;

	open TFILE, "$folder/tumor/$c";
	while(<TFILE>){
		$tumor_reads_count++;
	}
	print '\ntumor reads count:'.$tumor_reads_count.'\n';

	open TFILE, "$folder/control/$c";
	while(<TFILE>){
		$control_reads_count++;
	}
	print '\ncontrol reads count:'.$control_reads_count.'\n';

	$command = "$tool/txt2blk $folder/tumor/$c $folder/control/$c $blk/$name.blk\n";

    $command .= "$tool/seqcnv $blk/$name.blk $blk/$name.3.blk 3 $tumor_reads_count $control_reads_count\n";
    $command .= "$tool/seqcnv $blk/$name.3.blk $blk/$name.3.10.blk 10 $tumor_reads_count $control_reads_count\n";
    $command .= "$tool/seqcnv $blk/$name.3.10.blk $blk/$name.3.15.blk 15 $tumor_reads_count $control_reads_count\n";
	$command .= "$tool/seqcnv $blk/$name.3.15.blk $blk/$name.3.20.blk 20 $tumor_reads_count $control_reads_count\n";

    $command .= "$tool/blk2tsv $blk/$name.3.10.blk $folder/tsv/$name.3.10.tsv -1 -1\n";
    $command .= "$tool/blk2tsv $blk/$name.3.15.blk $folder/tsv/$name.3.15.tsv -1 -1\n";
	$command .= "$tool/blk2tsv $blk/$name.3.20.blk $folder/tsv/$name.3.20.tsv -1 -1\n";
	print STDOUT "$command\n";
	system($command);
}

sub usage {
	print "
Usage:
test seqcnv, run seqcnv allchr.
";
	exit;
}
