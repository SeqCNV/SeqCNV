#!/usr/bin/perl -w

use capture_filter;
use FileHandle;
use File::stat;
use Getopt::Long;

use vars qw($opt_help $opt_target_file $opt_expand $opt_control $opt_tumor $opt_out);

# Read opts
if ( !GetOptions( "help|h", "target_file|f:s", "expand|e:s", "control|c:s", "tumor|t:s", "out|o:s") ) {
        &usage(1);
}

my $target_file = $opt_target_file;
open( my $TARGET, '<', $target_file );

my $EXPAND = $opt_expand || 300;
capture_filter::load_targets($TARGET, $EXPAND, $EXPAND);
close($TARGET);

my $off = 0; my $on = 0;
my $input = "samtools view $opt_control |";
($off, $on) = capture_filter::seperate_by_chr("$opt_out/control", $input);
print STDERR "sample_name\toff_target\ton_target\n";
print STDERR "$opt_control\t$off\t$on\n";
close(IN);

$input = "samtools view $opt_tumor |";
($off, $on) = capture_filter::seperate_by_chr("$opt_out/tumor", $input);
print STDERR "sample_name\toff_target\ton_target\n";
print STDERR "$opt_tumor\t$off\t$on\n";
close(IN);

sub usage {
        print "
Usage:
output seqcnv format positions by chromosome
";
        exit;
}

